import React, { useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import Footer from "../components/Layout/Footer";
import Header from "../components/Layout/Header";
import PolishDetails from "../components/Polishes/PolishDetails";
import SuggestedPolish from "../components/Polishes/SuggestedPolish";
import { useSelector } from "react-redux";

const PolishDetailsPage = () => {
  const { allPolishes } = useSelector((state) => state.polishes);
  const { allEvents } = useSelector((state) => state.events);
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [searchParams] = useSearchParams();
  const eventData = searchParams.get("isEvent");

  console.log({allPolishes});
  

  useEffect(() => {
    if (eventData !== null) {
      const data = allEvents && allEvents.find((i) => i._id === id);
      setData(data);
    } else {
      const data = allPolishes && allPolishes.find((i) => i._id === id);
      setData(data);
    }
  }, [allPolishes, allEvents]);

  return (
    <div>
      <Header />
      <PolishDetails data={data} />
        {
          !eventData && (
            <>
            {data && <SuggestedPolish data={data} />}
            </>
          )
        }
      <Footer />
    </div>
  );
};

export default PolishDetailsPage;
