// export const server = "https://eshop-tutorial.vercel.app/api/v2";
export const server = "http://localhost:8000/api/v2";



